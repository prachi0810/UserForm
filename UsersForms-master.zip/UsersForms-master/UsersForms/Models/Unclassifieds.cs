﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace UsersForms.Models
{
    public class Unclassifieds
    {
        public int Id { get; set; }
        [Required]
        public string Title { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime Date { get; set; }
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{HH:MM:SS}", ApplyFormatInEditMode = true)]
        public DateTime Time { get;set; }   
        public string Location { get; set; }
        public string Details { get; set; }
        [Required]
        public string Category { get; set; }
        public string Information_Verified { get; set; }
        
    }

    public class Restricated
    {
        public Restricated()
        {
            Unclassifieds=new HashSet<Unclassifieds>();
        }
        public int Id { get; set; }
        [Required]
        public string Title { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime Date { get; set; }
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{HH:MM:SS}", ApplyFormatInEditMode = true)]
        public DateTime Time { get; set; }
        public string Location { get; set; }
        public string Details { get; set; }
        [Required]
        public string Category { get; set; }
        public string Information_Verified { get; set; }
        public virtual ICollection<Unclassifieds> Unclassifieds { get; set; }
    }
    public class Confidential
    {
        public Confidential()
        {
            Restricateds = new HashSet<Restricated>();
        }
        public int Id { get; set; }
        [Required]
        public string Title { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime Date { get; set; }
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{HH:MM:SS}", ApplyFormatInEditMode = true)]
        public DateTime Time { get; set; }
        public string Location { get; set; }
        public string Details { get; set; }
        [Required]
        public string Category { get; set; }
        public string Information_Verified { get; set; }
        public virtual ICollection<Restricated> Restricateds { get; set; }
        public virtual Unclassifieds Unclassifieds { get; set; }
    }
    public class TopSecret
    {
        public int Id { get; set; }
        [Required]
        public string Title { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime Date { get; set; }
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{HH:MM:SS}", ApplyFormatInEditMode = true)]
        public DateTime Time { get; set; }
        public string Location { get; set; }
        public string Details { get; set; }
        [Required]
        public string Category { get; set; }
        public string Information_Verified { get; set; }
    }

    public class UserDBContext:DbContext
    {
        public DbSet<Unclassifieds> unclassifieds { get; set; }
        public DbSet<Confidential> confidentials { get; set; }
        public DbSet<Restricated> restricateds { get; set; }
        public DbSet<TopSecret> topSecrets { get; set; }
    }
}