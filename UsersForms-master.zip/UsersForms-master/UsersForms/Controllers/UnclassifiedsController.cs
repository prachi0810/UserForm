﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UsersForms.Models;

namespace UsersForms.Controllers
{
    public class UnclassifiedsController : Controller
    {
        private UserDBContext db = new UserDBContext();

        // GET: Unclassifieds
        public ActionResult Index()
        {
            return View(db.unclassifieds.ToList());
        }

        // GET: Unclassifieds/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Unclassifieds unclassifieds = db.unclassifieds.Find(id);
            if (unclassifieds == null)
            {
                return HttpNotFound();
            }
            return View(unclassifieds);
        }

        // GET: Unclassifieds/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Unclassifieds/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Title,Date,Time,Location,Details,Category,Information_Verified")] Unclassifieds unclassifieds)
        {
            if (ModelState.IsValid)
            {
                db.unclassifieds.Add(unclassifieds);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(unclassifieds);
        }

        // GET: Unclassifieds/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Unclassifieds unclassifieds = db.unclassifieds.Find(id);
            if (unclassifieds == null)
            {
                return HttpNotFound();
            }
            return View(unclassifieds);
        }

        // POST: Unclassifieds/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Title,Date,Time,Location,Details,Category,Information_Verified")] Unclassifieds unclassifieds)
        {
            if (ModelState.IsValid)
            {
                db.Entry(unclassifieds).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(unclassifieds);
        }

        // GET: Unclassifieds/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Unclassifieds unclassifieds = db.unclassifieds.Find(id);
            if (unclassifieds == null)
            {
                return HttpNotFound();
            }
            return View(unclassifieds);
        }

        // POST: Unclassifieds/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Unclassifieds unclassifieds = db.unclassifieds.Find(id);
            db.unclassifieds.Remove(unclassifieds);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
