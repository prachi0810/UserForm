﻿namespace UsersForms.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitaialCreate1 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Confidentials", "Title", c => c.String(nullable: false));
            AlterColumn("dbo.Confidentials", "Category", c => c.String(nullable: false));
            AlterColumn("dbo.Restricateds", "Title", c => c.String(nullable: false));
            AlterColumn("dbo.Restricateds", "Category", c => c.String(nullable: false));
            AlterColumn("dbo.TopSecrets", "Title", c => c.String(nullable: false));
            AlterColumn("dbo.TopSecrets", "Category", c => c.String(nullable: false));
            AlterColumn("dbo.Unclassifieds", "Title", c => c.String(nullable: false));
            AlterColumn("dbo.Unclassifieds", "Category", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Unclassifieds", "Category", c => c.String());
            AlterColumn("dbo.Unclassifieds", "Title", c => c.String());
            AlterColumn("dbo.TopSecrets", "Category", c => c.String());
            AlterColumn("dbo.TopSecrets", "Title", c => c.String());
            AlterColumn("dbo.Restricateds", "Category", c => c.String());
            AlterColumn("dbo.Restricateds", "Title", c => c.String());
            AlterColumn("dbo.Confidentials", "Category", c => c.String());
            AlterColumn("dbo.Confidentials", "Title", c => c.String());
        }
    }
}
