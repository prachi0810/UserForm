﻿namespace UsersForms.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitaialCreate : DbMigration
    {
        public override void Up()
        {
            RenameTable(name: "dbo.Unclassifieds", newName: "Confidentials");
            CreateTable(
                "dbo.Restricateds",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Title = c.String(),
                        Date = c.DateTime(nullable: false),
                        Time = c.DateTime(nullable: false),
                        Location = c.String(),
                        Details = c.String(),
                        Category = c.String(),
                        Information_Verified = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.TopSecrets",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Title = c.String(),
                        Date = c.DateTime(nullable: false),
                        Time = c.DateTime(nullable: false),
                        Location = c.String(),
                        Details = c.String(),
                        Category = c.String(),
                        Information_Verified = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Unclassifieds",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Title = c.String(),
                        Date = c.DateTime(nullable: false),
                        Time = c.DateTime(nullable: false),
                        Location = c.String(),
                        Details = c.String(),
                        Category = c.String(),
                        Information_Verified = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Unclassifieds");
            DropTable("dbo.TopSecrets");
            DropTable("dbo.Restricateds");
            RenameTable(name: "dbo.Confidentials", newName: "Unclassifieds");
        }
    }
}
