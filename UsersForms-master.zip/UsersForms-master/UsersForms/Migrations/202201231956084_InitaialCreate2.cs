﻿namespace UsersForms.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitaialCreate2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Confidentials", "Unclassifieds_Id", c => c.Int());
            AddColumn("dbo.Restricateds", "Confidential_Id", c => c.Int());
            AddColumn("dbo.Unclassifieds", "Restricated_Id", c => c.Int());
            CreateIndex("dbo.Confidentials", "Unclassifieds_Id");
            CreateIndex("dbo.Restricateds", "Confidential_Id");
            CreateIndex("dbo.Unclassifieds", "Restricated_Id");
            AddForeignKey("dbo.Unclassifieds", "Restricated_Id", "dbo.Restricateds", "Id");
            AddForeignKey("dbo.Restricateds", "Confidential_Id", "dbo.Confidentials", "Id");
            AddForeignKey("dbo.Confidentials", "Unclassifieds_Id", "dbo.Unclassifieds", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Confidentials", "Unclassifieds_Id", "dbo.Unclassifieds");
            DropForeignKey("dbo.Restricateds", "Confidential_Id", "dbo.Confidentials");
            DropForeignKey("dbo.Unclassifieds", "Restricated_Id", "dbo.Restricateds");
            DropIndex("dbo.Unclassifieds", new[] { "Restricated_Id" });
            DropIndex("dbo.Restricateds", new[] { "Confidential_Id" });
            DropIndex("dbo.Confidentials", new[] { "Unclassifieds_Id" });
            DropColumn("dbo.Unclassifieds", "Restricated_Id");
            DropColumn("dbo.Restricateds", "Confidential_Id");
            DropColumn("dbo.Confidentials", "Unclassifieds_Id");
        }
    }
}
